# Detective Conan Planner V3

Upload `index.html` ke root repository GitHub Pages.

Fitur: kalender/tanggal tanpa batas, edit jam langsung, tombol + mobile-friendly, progress, streak, catatan unlimited secara aplikasi, export catatan, dan notifikasi browser.

Notifikasi web punya batasan browser: izin notifikasi harus diberikan dan timer halaman tidak selalu berjalan ketika tab/browser benar-benar ditutup atau disuspend.